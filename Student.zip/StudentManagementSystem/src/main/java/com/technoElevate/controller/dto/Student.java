package com.technoElevate.controller.dto;

import lombok.Data;

@Data
public class Student {
	private String sname;
	private int age ;
	private String pass;

}
