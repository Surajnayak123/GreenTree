package com.technoElevate.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.technoElevate.controller.dao.StudentMapper;
import com.technoElevate.controller.dto.Student;
import com.technoElevate.controller.service.ServiceLayaer;



@Controller
public class ControllerClass {
	
	@Autowired
	ServiceLayaer layer;
	@Autowired
	StudentMapper stuMap;
	

	@RequestMapping(path="/input" , method = RequestMethod.GET)
	public ModelAndView register(ModelAndView mvc) {
	      mvc.setViewName("/WEB-INF/views/input.jsp");
		return mvc;
	}
	@PostMapping("/result")
	public String getRequest(ModelMap map , Student student) {
			layer.getData(student);
	
			map.addAttribute("stu", student);
			return "/WEB-INF/views/result.jsp";
		
	}

	@RequestMapping(path="/login" , method = RequestMethod.GET)
	public ModelAndView login(ModelAndView mvc) {
	      mvc.setViewName("/WEB-INF/views/login.jsp");
		return mvc;
	}
	
	@PostMapping("/success")
	public String success(ModelMap map , Student student, HttpServletRequest request) {
			 boolean b = layer.matchingPass(student);
			 if (b) {
				 map.addAttribute("st", "Login Successful");
				 HttpSession session = request.getSession();
				 session.setAttribute("username", student.getSname());
				 return "/WEB-INF/views/success.jsp";
			}else {
				map.addAttribute("st", "Login Failed");
				return "/WEB-INF/views/login.jsp";
			}
	
//			 map.addAttribute("st", student);
//			return "/WEB-INF/views/success.jsp";
		
	}
	
	@GetMapping("/output")
	public String getTableDetail(ModelMap map, StudentMapper sm ) {
		
		map.addAttribute("detail",sm);
		
		return "/WEB-INF/views/output.jsp";
		
	}
	

	@RequestMapping(path="/Logout" , method = RequestMethod.GET)
	public ModelAndView logOut(ModelAndView mvc, HttpServletRequest req) {
		  HttpSession ss = req.getSession(false);
		  ss.getAttribute("username");
		  ss.invalidate();
	      mvc.setViewName("/WEB-INF/views/input.jsp");
		return mvc;
	}
	@RequestMapping(path="/Setting" , method = RequestMethod.GET)
	public ModelAndView setting(ModelAndView mvc, HttpServletRequest req) {
		  HttpSession ss = req.getSession(false);
		  ss.getAttribute("username");
		 
	      mvc.setViewName("/WEB-INF/views/Setting.jsp");
		return mvc;
	}
	@RequestMapping("/show")
	private String getAllDetail(ModelMap map , StudentMapper mapper) {
		 List<Student> student = stuMap.getDetail();
		 map.addAttribute("getStudent",student);
		
		return "/WEB-INF/views/show.jsp";
	}

}
