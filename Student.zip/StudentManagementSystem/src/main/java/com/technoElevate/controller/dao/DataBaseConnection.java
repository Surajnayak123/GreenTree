package com.technoElevate.controller.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.stereotype.Component;

import com.technoElevate.controller.dto.Student;


@Component
public class DataBaseConnection {
	
	public boolean addDetail(Student stu){
		boolean isInsert = false;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/login?user=root&password=root1234");
			PreparedStatement  prt= con.prepareStatement("insert into student values(?,?,?)");
			prt.setString(1, stu.getSname());
			prt.setInt(2, stu.getAge());
			prt.setString(3, stu.getPass());
			 prt.execute();
			isInsert = true;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		 return isInsert;
	}
	public String getPassword(Student stu) {
		String password = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/login?user=root&password=root1234");
			PreparedStatement  prt= con.prepareStatement("select * from student where sname = ? and password = ? ");
			prt.setString(1, stu.getSname());
			prt.setString(2, stu.getPass());
			ResultSet rs = prt.executeQuery();
			rs.next();
			password= rs.getString(3);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return password;
		
	}

}
