package com.technoElevate.controller.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.technoElevate.controller.dto.Student;



public class StudentMapper {
	
    JdbcTemplate templet;

	public JdbcTemplate getTemplet() {
		return templet;
	}

	public void setTemplet(JdbcTemplate templet) {
		this.templet = templet;
	}

	public List<Student> getDetail() {
		
		return templet.query("select * from student ", new RowMapper<Student>() {
			public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
			     Student stu = new Student();
			     stu.setSname(rs.getString(1));
			     stu.setAge(rs.getInt(2));
			     stu.setPass(rs.getString(3));
				 return stu;
			}
		});
		
	}

}
