package com.technoElevate.controller.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.technoElevate.controller.dto.Student;


@Component
public class StudentMapper {
	
    JdbcTemplate templet;

	public JdbcTemplate getTemplet() {
		return templet;
	}

	public void setTemplet(JdbcTemplate templet) {
		this.templet = templet;
	}

	public List<Student> getDetail() {
		
		return templet.query("select * from student ", new RowMapper<Student>() {
			public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
			     Student stu = new Student();
			     stu.setSname(rs.getString(1));
			     stu.setAge(rs.getInt(2));
			     stu.setPass(rs.getString(3));
				 return stu;
			}
		});
		
	}
	
	public int getDelete(String name) {
		
		String query = "delete from student where sname = ? ";
		return templet.update(query,name);
		
	}
	
	public int getUpdate(String newPassword,String name) {
		String query = "update student set password = ? where sname = ?";
		
		return templet.update(query,newPassword,name);
	}

}
