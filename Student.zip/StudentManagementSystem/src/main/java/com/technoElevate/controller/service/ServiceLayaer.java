package com.technoElevate.controller.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.technoElevate.controller.dto.Student;
import com.technoElevate.controller.dao.DataBaseConnection;

@Component
public class ServiceLayaer {
    @Autowired
	DataBaseConnection database;
	
	
	public boolean getData(Student stu) {
		
		if (stu.getAge() > 0 && stu.getSname() != null) {
			return	 database.addDetail(stu);
		}else {
			return false;
		}
		
		
	}
	
	public boolean matchingPass(Student stu) {
		boolean login = false;
		 
		if(stu.getPass().equals(database.getPassword(stu))) {
			return true;
		}else {
			return false;
		}
		
	}

}
