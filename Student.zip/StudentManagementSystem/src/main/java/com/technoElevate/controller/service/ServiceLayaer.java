package com.technoElevate.controller.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import com.technoElevate.controller.dto.Student;
import com.technoElevate.controller.dao.DataBaseConnection;
import com.technoElevate.controller.dao.StudentMapper;

@Component
public class ServiceLayaer  {
    @Autowired
	DataBaseConnection database;
   
    
    ApplicationContext context = new ClassPathXmlApplicationContext("com/technoElevate/controller/service/config.xml");
	StudentMapper doa = context.getBean("stuMap" , StudentMapper.class);
	
	
	public boolean getData(Student stu) {
		
		if (stu.getAge() > 0 && stu.getSname() != null) {
			return	 database.addDetail(stu);
		}else {
			return false;
		}
		
		
	}
	
	public boolean matchingPass(Student stu) {
		boolean login = false;
		 
		if(stu.getPass().equals(database.getPassword(stu))) {
			login =  true;
		}else {
			login =  false;
		}
		
		return login;
		
	}
	
	public List<Student> detail() {
		
		List<Student> stuDetail = doa.getDetail();
		
		 return stuDetail;
		
	}
	
	
	public boolean remove(String name) {
		boolean result = false;
		if (doa.getDelete(name) == 1) {
			result = true;
		}else {
			result = false;
		}
	     
		return result;
	}
	
	public boolean update(String newPassword,String name) {
		if(	doa.getUpdate(newPassword, name)==1) {
			return true;
		}else {
			return false;
		}
	
		
		
	}

}
